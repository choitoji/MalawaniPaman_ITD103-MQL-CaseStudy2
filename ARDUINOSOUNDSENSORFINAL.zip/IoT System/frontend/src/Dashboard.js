import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

const Dashboard = () => {
  const [audioData, setAudioData] = useState([]);
  const [filteredData, setFilteredData] = useState([]);
  const [error, setError] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const rowsPerPage = 10;

  useEffect(() => {
    const fetchData = async () => {
      try {
        const result = await axios.get('http://localhost:3000/api/audio');
        setAudioData(result.data);
        setFilteredData(result.data);
      } catch (error) {
        setError(error);
      }
    };
    fetchData();
  }, []);

  const handleSearch = (event) => {
    setSearchTerm(event.target.value);
    if (event.target.value === '') {
      setFilteredData(audioData);
      setError(null);
    } else {
      const filtered = audioData.filter(data =>
        data.level.toString().includes(event.target.value)
      );
      setFilteredData(filtered);
      if (filtered.length === 0) {
        setError('No matching results found');
      } else {
        setError(null);
      }
    }
    setCurrentPage(1);
  };

  const handlePrevPage = () => {
    if (currentPage > 1) {
      setCurrentPage(currentPage - 1);
    }
  };

  const handleNextPage = () => {
    if (currentPage * rowsPerPage < filteredData.length) {
      setCurrentPage(currentPage + 1);
    }
  };

  const indexOfLastRow = currentPage * rowsPerPage;
  const indexOfFirstRow = indexOfLastRow - rowsPerPage;
  const currentRows = filteredData.slice(indexOfFirstRow, indexOfLastRow);

  return (
    <div className="container mx-auto p-4 bg-gray-100 min-h-screen">
      <header className="bg-white shadow-md rounded p-4 mb-8">
        <h1 className="text-4xl font-bold text-center text-blue-600">Audio Loudness Dashboard</h1>
      </header>
      <div className="bg-white shadow-md rounded p-4 mb-8">
        <h2 className="text-2xl font-semibold mb-4">Recent Sound Levels</h2>
        <ResponsiveContainer width="100%" height={400}>
          <LineChart
            data={audioData}
            margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
          >
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="timestamp" tickFormatter={(timestamp) => new Date(timestamp).toLocaleTimeString()} />
            <YAxis />
            <Tooltip labelFormatter={(label) => new Date(label).toLocaleTimeString()} />
            <Legend />
            <Line type="monotone" dataKey="level" stroke="#8884d8" activeDot={{ r: 8 }} />
          </LineChart>
        </ResponsiveContainer>
      </div>
      <hr className="my-8 border-gray-300" />
      <div className="bg-white shadow-md rounded p-4 mb-8">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-2xl font-semibold">Sound Level Data</h2>
          <input
            type="text"
            placeholder="Search by sound level..."
            value={searchTerm}
            onChange={handleSearch}
            className="py-2 px-4 rounded-full border border-gray-400"
          />
        </div>
        {error && <div className="text-red-500 mb-4">{error}</div>}
        <div className="overflow-auto">
          <table className="min-w-full bg-white">
            <thead className="bg-gray-800 text-white">
              <tr>
                <th className="w-1/3 py-2">Timestamp</th>
                <th className="w-1/3 py-2">Sound Level</th>
              </tr>
            </thead>
            <tbody className="text-gray-700">
              {currentRows.map((data, index) => (
                <tr key={index} className="border-b">
                  <td className="py-2 px-4">{new Date(data.timestamp).toLocaleString()}</td>
                  <td className="py-2 px-4">{data.level}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="flex justify-between items-center mt-4">
          <button
            onClick={handlePrevPage}
            disabled={currentPage === 1}
            className="bg-gray-300 text-gray-800 py-1 px-3 rounded disabled:opacity-50"
          >
            &lt; Previous
          </button>
          <span className="text-gray-700">Page {currentPage}</span>
          <button
            onClick={handleNextPage}
            disabled={currentPage * rowsPerPage >= filteredData.length}
            className="bg-gray-300 text-gray-800 py-1 px-3 rounded disabled:opacity-50"
          >
            Next &gt;
          </button>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;